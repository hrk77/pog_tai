<?php 

//vars que vao receber dados
$mensagem = "Preencha esse formúlario";
$nome = "";
$email = "";
$msg = "";

//verificar se os dados estao chegando ao BD
//os nomes devem estar iguais ao banco criado

if (isset($_POST["nome"],$_POST["email"],$_POST["msg"])){
    //se as variaveis forem verdadeiras vai inicar a conexao com o banco
    $conexao = new PDO("mysql:host=127.0.0.1;dbname=site1", "root", "");

    //atribuindo os valores dos inputs para as variaveis
    // o filter_input, limpa os dados depois de inseridos

    $nome = filter_input(INPUT_POST, "nome", FILTER_UNSAFE_RAW);
    $email = filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL);
    $msg = filter_input(INPUT_POST, "msg", FILTER_UNSAFE_RAW);


    //verificar se o usuario digitou dados invalidos
    if(!$nome || !$email || !$msg){
        $mensagem = "Dados inválidos";

    }else{
        //vai inserir os dados na tabela no BD
        $stm = $conexao->prepare('INSERT INTO contato (nome, email, msg,) VALUES (:nome, :email, :msg)');

        //bindParam = informar valores dinamicamente para uma requisiçao
        //SQL USANDO PHP, ATRAVES DE UMA VARIAVEL OU CONSANTE

        $stm->bindParam('nome', $nome);
        $stm ->bindParam('email',$email);
        $stm ->bindParam('msg',$msg);
        $stm->execute();

        $mensagem = "Mensagem enviada com exito";

        //limpar campos quando a sg for enviada
        $nome = "";
        $email = "";
        $msg = "";


    }
}