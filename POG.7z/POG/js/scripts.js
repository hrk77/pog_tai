$(function(){
    $('nav.mobile').click(function(){
        //qndo clicar ele vai chama essa funcao
        //vou criar uma variavel PARA SER acessada
        var listaMenu = $('nav.mobile ul');
        //listamenu.fadeIn(); //chama efeito
//        if(listaMenu.is(':hidden') == true)
//            listaMenu.fadeIn();
//        else
//            listaMenu.fadeIn();
//        else
//            listaMenu;fadeOut();
//            listaMenu.slideToggle(); //abre cortina

//        if(listaMenu.listaMenu(':hidden') == true)
//            listaMenu.show();
//        else
//            listaMenu.hide();

    if(listaMenu.is(':hidden') == true){
        var icone = $('botao-menu-mobile').find('i');
        icone.removeCLass('fa-bars');
        icone.addClass('fa-times');
        listaMenu.slideToggle();
    }else {
        var icone = $('botao-menu-mobile').find('i');
        icone.removeCLass('fa-times');
        icone.addClass('fa-bars');
        listaMenu.slideToggle();
    }






    })

})
